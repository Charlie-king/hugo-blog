---
title: "Friends"
subtitle: Recording some friends who use FixIt theme
type: "friends"
description: "Friends tempalate demo of FixIt theme"
keywords: 
  - Hugo
  - friends tempalate
comment: true
---

---

{{< admonition tip "Add your FixIt site" >}}
You could add your FixIt site to this page via [making a PR :(fas fa-code-branch fa-fw):](https://github.com/Lruihao/FixIt/pulls). (e.g. [#111](https://github.com/Lruihao/FixIt/pull/111))

> :(fas fa-exclamation-triangle): *Website failure, stop maintenance and improper content may be unlinked!*
{{< /admonition >}}
