---
title: "友情链接"
subtitle: 记录一些使用 FixIt 主题的朋友们
type: "friends"
description: "FixIt 主题的友链模板 Demo"
keywords: 
  - Hugo
  - 友情链接
comment: true
---

---

{{< admonition tip "添加您的 FixIt 网站" >}}
您可以通过 [创建 PR :(fas fa-code-branch fa-fw):](https://github.com/Lruihao/FixIt/pulls) 将您的 FixIt 网站添加到此页面。（例如：[#111](https://github.com/Lruihao/FixIt/pull/111)）

> :(fas fa-exclamation-triangle): *网站失效、停止维护、不当内容都可能被取消链接！*
{{< /admonition >}}
