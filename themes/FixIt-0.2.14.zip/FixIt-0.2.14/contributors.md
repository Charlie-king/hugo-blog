# Contributors-Readme

## Collaborators

<!-- readme: collaborators -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/Lruihao">
            <img src="https://avatars.githubusercontent.com/u/33419593?v=4" width="100;" alt="Lruihao"/>
            <br />
            <sub><b>Cell</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/pandaoh">
            <img src="https://avatars.githubusercontent.com/u/38677740?v=4" width="100;" alt="pandaoh"/>
            <br />
            <sub><b>DoubleAm</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/hiifong">
            <img src="https://avatars.githubusercontent.com/u/89133723?v=4" width="100;" alt="hiifong"/>
            <br />
            <sub><b>Hiifong</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: collaborators -end -->

## [Contributors](https://github.com/Lruihao/FixIt/graphs/contributors)

<!-- readme: contributors,d-baer -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/dillonzq">
            <img src="https://avatars.githubusercontent.com/u/30786232?v=4" width="100;" alt="dillonzq"/>
            <br />
            <sub><b>Dillon</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Lruihao">
            <img src="https://avatars.githubusercontent.com/u/33419593?v=4" width="100;" alt="Lruihao"/>
            <br />
            <sub><b>Cell</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Fastbyte01">
            <img src="https://avatars.githubusercontent.com/u/16869546?v=4" width="100;" alt="Fastbyte01"/>
            <br />
            <sub><b>Giuseppe Pignataro</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Programazing">
            <img src="https://avatars.githubusercontent.com/u/11393826?v=4" width="100;" alt="Programazing"/>
            <br />
            <sub><b>Christopher C. Johnson</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/astropenguin">
            <img src="https://avatars.githubusercontent.com/u/13254278?v=4" width="100;" alt="astropenguin"/>
            <br />
            <sub><b>Akio Taniguchi</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/DaveA-W">
            <img src="https://avatars.githubusercontent.com/u/6415842?v=4" width="100;" alt="DaveA-W"/>
            <br />
            <sub><b>Dave A-W</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/maxlefou">
            <img src="https://avatars.githubusercontent.com/u/6705075?v=4" width="100;" alt="maxlefou"/>
            <br />
            <sub><b>JM Fergeau</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/realsangil">
            <img src="https://avatars.githubusercontent.com/u/15508203?v=4" width="100;" alt="realsangil"/>
            <br />
            <sub><b>Sangil Park</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Fedomn">
            <img src="https://avatars.githubusercontent.com/u/6177727?v=4" width="100;" alt="Fedomn"/>
            <br />
            <sub><b>Frank Ma</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ctj12461">
            <img src="https://avatars.githubusercontent.com/u/42143810?v=4" width="100;" alt="ctj12461"/>
            <br />
            <sub><b>Justin Chen</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/edte">
            <img src="https://avatars.githubusercontent.com/u/50194671?v=4" width="100;" alt="edte"/>
            <br />
            <sub><b>Edte</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/solarpowerinncr">
            <img src="https://avatars.githubusercontent.com/u/37186560?v=4" width="100;" alt="solarpowerinncr"/>
            <br />
            <sub><b>Solarpowerinncr</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/youngxhui">
            <img src="https://avatars.githubusercontent.com/u/16971804?v=4" width="100;" alt="youngxhui"/>
            <br />
            <sub><b>Youngxhui</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/dogukanerel">
            <img src="https://avatars.githubusercontent.com/u/19349444?v=4" width="100;" alt="dogukanerel"/>
            <br />
            <sub><b>Doğukan Erel</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/devandreacarratta">
            <img src="https://avatars.githubusercontent.com/u/46504271?v=4" width="100;" alt="devandreacarratta"/>
            <br />
            <sub><b>Andrea Carratta</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/cmpsoares91">
            <img src="https://avatars.githubusercontent.com/u/4914211?v=4" width="100;" alt="cmpsoares91"/>
            <br />
            <sub><b>Carlos Manuel Soares</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/AutomationD">
            <img src="https://avatars.githubusercontent.com/u/1790594?v=4" width="100;" alt="AutomationD"/>
            <br />
            <sub><b>Dmitry Kireev</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/thejayhaykid">
            <img src="https://avatars.githubusercontent.com/u/9452325?v=4" width="100;" alt="thejayhaykid"/>
            <br />
            <sub><b>Jake Hayes</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/markdluethje">
            <img src="https://avatars.githubusercontent.com/u/31922494?v=4" width="100;" alt="markdluethje"/>
            <br />
            <sub><b>Mark-Daniel Lüthje</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/nirgn975">
            <img src="https://avatars.githubusercontent.com/u/3472902?v=4" width="100;" alt="nirgn975"/>
            <br />
            <sub><b>Nir Galon</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ramrodo">
            <img src="https://avatars.githubusercontent.com/u/2797052?v=4" width="100;" alt="ramrodo"/>
            <br />
            <sub><b>Rodolfo Martínez Vega</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/SilkeHenderickx">
            <img src="https://avatars.githubusercontent.com/u/28140438?v=4" width="100;" alt="SilkeHenderickx"/>
            <br />
            <sub><b>Silke Henderickx</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/tlereste">
            <img src="https://avatars.githubusercontent.com/u/12964583?v=4" width="100;" alt="tlereste"/>
            <br />
            <sub><b>Thibault Le Reste</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/vanildosouto">
            <img src="https://avatars.githubusercontent.com/u/1603028?v=4" width="100;" alt="vanildosouto"/>
            <br />
            <sub><b>Vanildo Souto Mangueira</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/victor-pogor">
            <img src="https://avatars.githubusercontent.com/u/24962085?v=4" width="100;" alt="victor-pogor"/>
            <br />
            <sub><b>Victor Pogor</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/wtchangdm">
            <img src="https://avatars.githubusercontent.com/u/1546333?v=4" width="100;" alt="wtchangdm"/>
            <br />
            <sub><b>W.T. Chang</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/anup92k">
            <img src="https://avatars.githubusercontent.com/u/51033013?v=4" width="100;" alt="anup92k"/>
            <br />
            <sub><b>Anup</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/codedge">
            <img src="https://avatars.githubusercontent.com/u/4409904?v=4" width="100;" alt="codedge"/>
            <br />
            <sub><b>Holger Lösken</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/hiifong">
            <img src="https://avatars.githubusercontent.com/u/89133723?v=4" width="100;" alt="hiifong"/>
            <br />
            <sub><b>Hiifong</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/onisuly">
            <img src="https://avatars.githubusercontent.com/u/8399827?v=4" width="100;" alt="onisuly"/>
            <br />
            <sub><b>Onisuly</b></sub>
        </a>
    </td></tr>
<tr>
    <td align="center">
        <a href="https://github.com/quyleanh">
            <img src="https://avatars.githubusercontent.com/u/9365035?v=4" width="100;" alt="quyleanh"/>
            <br />
            <sub><b>Quy Le Anh</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/sarathsp06">
            <img src="https://avatars.githubusercontent.com/u/964542?v=4" width="100;" alt="sarathsp06"/>
            <br />
            <sub><b>Sarath Sadasivan Pillai</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/tomaja-linuxo">
            <img src="https://avatars.githubusercontent.com/u/37209662?v=4" width="100;" alt="tomaja-linuxo"/>
            <br />
            <sub><b>Tomaja</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/ziobron">
            <img src="https://avatars.githubusercontent.com/u/4595135?v=4" width="100;" alt="ziobron"/>
            <br />
            <sub><b>Łukasz Ziobroń</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/d-baer">
            <img src="https://avatars.githubusercontent.com/u/22482986?v=4" width="100;" alt="d-baer"/>
            <br />
            <sub><b>D-baer</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: contributors,d-baer -end -->

## Bots

<!-- readme: bots -start -->
<table>
<tr>
    <td align="center">
        <a href="https://github.com/dependabot[bot]">
            <img src="https://avatars.githubusercontent.com/in/29110?v=4" width="100;" alt="dependabot[bot]"/>
            <br />
            <sub><b>dependabot[bot]</b></sub>
        </a>
    </td></tr>
</table>
<!-- readme: bots -end -->